/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided "as is" and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.simpleexample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aevi.payment.AccountType;
import com.aevi.payment.CardEntryType;
import com.aevi.payment.CardType;
import com.aevi.payment.CompletionRequest;
import com.aevi.payment.DepositRequest;
import com.aevi.payment.MoToPaymentRequest;
import com.aevi.payment.MoToRefundRequest;
import com.aevi.payment.MoToRequestType;
import com.aevi.payment.PaymentAppConfiguration;
import com.aevi.payment.PaymentRequest;
import com.aevi.payment.PreAuthorisationRequest;
import com.aevi.payment.RefundRequest;
import com.aevi.payment.ReversalRequest;
import com.aevi.payment.TokenRequest;
import com.aevi.payment.TransactionReferences;
import com.aevi.payment.TransactionReferenceCode;
import com.aevi.payment.TransactionResult;
import com.aevi.payment.TransactionStatus;
import com.aevi.payment.TransactionType;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Currency;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Payment Activity demonstrates various payment request and their configuration options.
 */
public class PaymentActivity extends BasePaymentConfigActivity {

    private static final String TAG = PaymentActivity.class.getSimpleName();

    // Request codes for payments and refunds respectively. These are used in onActivityResult to check
    // whether the returned transaction was initiated by a payment- or refund request.
    private static final int PAYMENT = 0;
    private static final int PAYMENT_DEFAULT_CURRENCY = 1;
    private static final int REFUND = 2;
    private static final int MOTO_PAYMENT = 3;
    private static final int MOTO_REFUND = 4;
    private static final int REVERSAL = 5;
    private static final int PRE_AUTHORISATION = 6;
    private static final int COMPLETION = 7;
    private static final int DEPOSIT = 8;
    private static final int TOKEN = 9;

    private TransactionReferences transactionReferences;
    private Spinner dropdown;
    private TransactionType lastTxType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setButtonState();
    }

    @Override
    void onPaymentConfigurationResults(PaymentAppConfiguration paymentAppConfiguration) {
        checkStatus(paymentAppConfiguration);
        updateCurrencyDropdown(paymentAppConfiguration);
    }

    private void updateCurrencyDropdown(PaymentAppConfiguration configuration) {
        List<Currency> currencies = getCurrencies(configuration);
        Currency defaultCurrency = getDefaultCurrency(configuration);
        dropdown = (Spinner) findViewById(R.id.currencyDropDown);
        dropdown.setAdapter(new CurrencyListAdapter(currencies));
        if (defaultCurrency != null) {
            int defaultCurrencyIndex = currencies.indexOf(defaultCurrency);
            dropdown.setSelection(defaultCurrencyIndex);
        }
        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateButtonTexts();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                updateButtonTexts();
            }
        });
    }

    private void updateButtonTexts() {
        LinearLayout layout = (LinearLayout) findViewById(R.id.paymentActivityPage);
        for (int viewIndex = 0; viewIndex < layout.getChildCount(); viewIndex++) {
            View child = layout.getChildAt(viewIndex);
            if (child instanceof Button) {
                Button button = (Button) child;
                updateButtonText(button);
            }
        }
    }

    /**
     * The text of the button is stored in the tag. In this method
     * the %s's are replaced with the current code of the current currency.
     *
     * @param button
     */
    private void updateButtonText(Button button) {
        String tag = (String) button.getTag();
        Pattern currencyPattern = Pattern.compile("%s");
        Matcher matcher = currencyPattern.matcher(tag);
        List<String> currencyCodes = new ArrayList<String>();
        while (matcher.find()) {
            currencyCodes.add(getSelectedCurrency().getCurrencyCode());
        }
        if (currencyCodes.size() > 0) {
            button.setText(String.format(tag, currencyCodes.toArray()));
        } else {
            button.setText(tag);
        }
    }

     /**
     * Pay 19.99
     *
     * @param view The view that was clicked.
     */
    public void payment1Click(View view) {
        Log.i(TAG, "sending payment request");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("19.99"));
        payment.setCurrency(getSelectedCurrency());
        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    /**
     * Pay 19.99 on chip and pin card
     *
     * @param view The view that was clicked.
     */
    public void payment1ClickChip(View view) {
        Log.i(TAG, "sending payment request chip card only");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("19.99"));
        payment.setAcceptedCardEntryTypes(CardEntryType.CHIP);
        payment.setCurrency(getSelectedCurrency());
        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    /**
     * Pay 19.99 on visa
     *
     * @param view The view that was clicked.
     */
    public void payment1ClickVisa(View view) {
        Log.i(TAG, "sending payment request visa only");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("19.99"));
        payment.setAcceptedCardTypes(CardType.VISA);
        payment.setCurrency(getSelectedCurrency());
        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    /**
     * Pay 19.99 from savings account
     *
     * @param view The view that was clicked.
     */
    public void payment1ClickSavings(View view) {
        Log.i(TAG, "sending payment request from savings account");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("19.99"));
        payment.setAcceptedAccountTypes(AccountType.SAVINGS);
        payment.setCurrency(getSelectedCurrency());
        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    private Currency getSelectedCurrency() {
        return (Currency) dropdown.getSelectedItem();
    }

    /**
     * Pay 43.25 AUD with a 10% tip
     *
     * @param view The view that was clicked.
     */
    public void payment2Click(View view) {
        Log.i(TAG, "sending payment request");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("43.25"));
        payment.setCurrency(getSelectedCurrency());

        // The tipping amount is given here as an absolute amount.
        payment.setTipAmount(new BigDecimal("4.32"));

        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    /**
     * Pay 21.50 EUR with a 50 EUR cash-out"
     *
     * @param view The view that was clicked.
     */
    public void payment3Click(View view) {
        Log.i(TAG, "sending payment request");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("21.50"));
        payment.setCurrency(getSelectedCurrency());
        payment.setCashOutAmount(new BigDecimal("50.00"));
        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    /**
     * Pay 126.99 USD with a 5% tip and 100 USD cash-out.
     *
     * @param view The view that was clicked.
     */
    public void payment4Click(View view) {
        Log.i(TAG, "sending payment request");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("126.99"));
        payment.setCurrency(getSelectedCurrency());
        payment.setTipAmount(new BigDecimal(126.99 * 0.05).setScale(2, BigDecimal.ROUND_FLOOR));
        payment.setCashOutAmount(new BigDecimal("100.00"));
        startActivityForResult(payment.createIntent(), PAYMENT);
    }

    /**
     * Attempts to pay 80 units of the default currency
     *
     * @param view The view that was clicked.
     */
    public void payment5Click(View view) {
        Log.i(TAG, "sending payment request");

        PaymentRequest payment = new PaymentRequest(new BigDecimal("80.00"));
        startActivityForResult(payment.createIntent(), PAYMENT_DEFAULT_CURRENCY);
    }

    /**
     * Starts a refund transaction for 50 units of the Selected currency.
     *
     * @param view The view that was clicked.
     */
    public void refundClick(View view) {
        Log.i(TAG, "sending refund request");

        RefundRequest refund = new RefundRequest(new BigDecimal("50.00"));
        refund.setCurrency(getSelectedCurrency());
        startActivityForResult(refund.createIntent(), REFUND);
    }

    /**
     * Starts a MoTo (Mail Order Telephone Order) payment for 50 of the selected currency
     *
     * @param view The view that was clicked.
     */
    public void moToPaymentClick(View view) {
        Log.i(TAG, "sending moto payment request");

        MoToPaymentRequest payment = new MoToPaymentRequest(new BigDecimal("50.00"));
        payment.setMoToRequestType(MoToRequestType.TELEPHONE);
        payment.setCurrency(getSelectedCurrency());

        startActivityForResult(payment.createIntent(), MOTO_PAYMENT);
    }

    /**
     * Starts a MoTo (Mail Order Telephone Order) payment for 50 units
     * of the selected currency
     *
     * @param view The view that was clicked.
     */
    public void moToRefundClick(View view) {
        Log.i(TAG, "sending moto refund request");

        MoToRefundRequest refund = new MoToRefundRequest(new BigDecimal("50.00"));
        refund.setCurrency(getSelectedCurrency());
        startActivityForResult(refund.createIntent(), MOTO_REFUND);
    }

    /**
     * Reverse the last stored request
     *
     * @param view The view that was clicked.
     */
    public void reverseLastTransactionClick(View view) {
        Log.i(TAG, "sending reversal request");

        if (transactionReferences == null) {
            Toast.makeText(this, "No transaction references found. Please send a Payment or Refund request before sending a Reversal request.", Toast.LENGTH_LONG).show();
            return;
        }

        // Reversal of the last transaction sends the cached transaction references to the Simulator
        // to request the cancellation of that specific transaction.
        //
        // Please note that only the last (i.e. previous) transaction of can be cancelled.
        // This last transaction needs to be of type payment (PaymentRequest, MotoPaymentRequest) or refund (RefundRequest or MotoRefund)
        // Other transaction types such as a pre-authorisation can not be reversed.
        //
        // Also note that sending a reversal request overrides the last transaction with the reversal request.
        // This means you can not send two reversal requests after each other since a 'reversal request' itself can not be reversed.

        ReversalRequest reversal = new ReversalRequest(transactionReferences);
        startActivityForResult(reversal.createIntent(), REVERSAL);

        // clear the transaction reference indicating it's been processed.
        transactionReferences = null;
    }

    /**
     * Make a preauthorisation request for 50 units of the selected currency
     *
     * @param view
     */
    public void preAuthorisationRequestClick(View view) {
        Log.i(TAG, "sending pre-authorisation request");

        PreAuthorisationRequest preAuth = new PreAuthorisationRequest(new BigDecimal("50.00"));
        preAuth.setCurrency(getSelectedCurrency());
        startActivityForResult(preAuth.createIntent(), PRE_AUTHORISATION);
    }

    /**
     * Complete the previously preauthorized transaction
     *
     * @param view
     */
    public void completionRequestClick(View view) {
        Log.i(TAG, "sending completion request");

        if (transactionReferences == null) {
            Toast.makeText(this, "No transaction references found. Please send a Pre Authorisation request before sending a Completion request.", Toast.LENGTH_LONG).show();
            return;
        }

        // Completion of a Pre-Auth sends the cached transaction references to the Simulator
        // to request the completion of that specific transaction.

        CompletionRequest completionRequest = new CompletionRequest(transactionReferences);
        startActivityForResult(completionRequest.createIntent(), COMPLETION);
    }

    /**
     * Make a deposit request for 50 units of the selected currency
     *
     * @param view
     */
    public void depositClick(View view) {
        Log.i(TAG, "sending deposit request");

        DepositRequest deposit = new DepositRequest(new BigDecimal("50.00"));
        deposit.setCurrency(getSelectedCurrency());
        deposit.setExtraReference("ID","12345ABCDE");
        startActivityForResult(deposit.createIntent(), DEPOSIT);
    }

    /**
     * Make a token request
     * @param view
     */
    public void tokenTransactionClick(View view) {
        Log.i(TAG, "sending token request");

        TokenRequest token = new TokenRequest(BigDecimal.ZERO);
        token.setCurrency(getSelectedCurrency());
        token.setExtraReference("ID","12345ABCDE");
        startActivityForResult(token.createIntent(), TOKEN);
    }

    public void goSetCardEntryTypes(View view) {
        Log.i(TAG, "Setting card entry types");


    }

    /**
     * Called by Android when the payment application transfers control back to ours. The requestCode was set in the
     * startActivityForResult call, and is one of Payment or REFUND (see above).
     *
     * @param requestCode the request code sent along with the request
     * @param resultCode  the intent result code
     * @param data        the intent data
     * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode != Activity.RESULT_OK) {
            return;
        }

        if (requestCode == PAYMENT_CONFIGURATION) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }

        // Store the transaction references, these are needed to reverse the last transaction in the 'reversal example'
        // and to complete the pre-auth in the 'Pre authorisation example'
        TransactionResult transactionResult = TransactionResult.fromIntent(data);
        if (transactionResult.getTransactionStatus() == TransactionStatus.APPROVED) {
            transactionReferences = transactionResult.getTransactionReferences();

            TransactionReferenceCode[] txCodes = transactionReferences.getTransactionCodes();

            for ( TransactionReferenceCode txCode : txCodes){
                Log.i(TAG,"TXCode Name: " + txCode.getName() + ", Value: " + txCode.getValue());
            }
        } else {
            transactionReferences = null;
        }

        // call the correct result handler
        switch (requestCode) {
            case PAYMENT:
                lastTxType = TransactionType.PAYMENT;
                onPaymentComplete(transactionResult, PaymentRequest.fromIntent(data));
                break;
            case PAYMENT_DEFAULT_CURRENCY:
                lastTxType = TransactionType.PAYMENT;
                onPaymentDefaultCurrencyComplete(transactionResult, PaymentRequest.fromIntent(data));
                break;
            case REFUND:
                lastTxType = TransactionType.REFUND;
                onRefundComplete(transactionResult, RefundRequest.fromIntent(data));
                break;
            case MOTO_PAYMENT:
                lastTxType = TransactionType.MOTO_PAYMENT;
                onMoToPaymentComplete(transactionResult, MoToPaymentRequest.fromIntent(data));
                break;
            case MOTO_REFUND:
                lastTxType = TransactionType.MOTO_REFUND;
                onMoToRefundComplete(transactionResult, MoToRefundRequest.fromIntent(data));
                break;
            case DEPOSIT:
                lastTxType = TransactionType.DEPOSIT;
                onDepositComplete(transactionResult, DepositRequest.fromIntent(data));
                break;
            case TOKEN:
                lastTxType = TransactionType.TOKEN;
                onTokenComplete(transactionResult, TokenRequest.fromIntent(data));
                break;
            case REVERSAL:
                lastTxType = TransactionType.REVERSAL;
                onReversalComplete(transactionResult);
                break;
            case PRE_AUTHORISATION:
                lastTxType = TransactionType.PRE_AUTHORISATION;
                onPreAuthorisationComplete(transactionResult, PreAuthorisationRequest.fromIntent(data));
                break;
            case COMPLETION:
                lastTxType = TransactionType.COMPLETION;
                onCompletionComplete(transactionResult);
                break;
            default:
                lastTxType = null;
                showMessage("Unhandled request code " + requestCode);
                break;
        }

        setButtonState();
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a payment request.
     *
     * @param result  the transaction result
     * @param request the request
     */
    private void onPaymentComplete(TransactionResult result, PaymentRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("Payment completed. Total amount: " + request.getTotalAmount() + ", currency: " + request.getCurrency().getCurrencyCode() + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("Payment failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a payment request.
     *
     * @param result  the transaction result
     * @param request the request
     */
    private void onPaymentDefaultCurrencyComplete(TransactionResult result, PaymentRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("Payment completed. Total amount: " + request.getTotalAmount() + ", currency: DEFAULT CURRENCY" + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("Payment failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a refund request.
     *
     * @param result  the transaction result
     * @param request the request
     */
    private void onRefundComplete(TransactionResult result, RefundRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("Refund completed. Total amount: " + request.getAmount() + ", currency: " + request.getCurrency().getCurrencyCode() + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("Refund failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a MoTo payment request.
     *
     * @param result  the transaction result
     * @param request the request
     */
    private void onMoToPaymentComplete(TransactionResult result, MoToPaymentRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("MoToPayment completed. Total amount: " + request.getAmount() + ", currency: " + request.getCurrency().getCurrencyCode() + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("MoToPayment failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a MoTo refund request.
     *
     * @param result  the transaction result
     * @param request the request
     */
    private void onMoToRefundComplete(TransactionResult result, MoToRefundRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("MoToRefund completed. Total amount: " + request.getAmount() + ", currency: " + request.getCurrency().getCurrencyCode() + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("MoToRefund failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a reversal request.
     *
     * @param result the transaction result
     */
    private void onReversalComplete(TransactionResult result) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("Reversal completed. Last transaction has been reverted.");

            // clear transaction references from the actual reversal
            transactionReferences = null;
        } else {
            // transaction failed
            showErrorMessage("Reversal failed", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a pre authorisation request.
     *
     * @param result the transaction result
     */
    private void onPreAuthorisationComplete(TransactionResult result, PreAuthorisationRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("PreAuthorisation completed. Total amount: " + request.getAmount() + ", currency: " + request.getCurrency().getCurrencyCode() + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("Pre-authorisation failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a completion request.
     *
     * @param result the transaction result
     */
    private void onCompletionComplete(TransactionResult result) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("Pre-Auth Completion request successful");

            // clear transaction references from the actual pre-auth complete
            transactionReferences = null;
        } else {
            // transaction failed
            showErrorMessage("Completion failed.", result);
        }
    }

    /**
     * Called by onActivityResult when the payment application returned after servicing a deposit request.
     *
     * @param result the transaction result
     */
    private void onDepositComplete(TransactionResult result, DepositRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            showMessage("Deposit completed. Total amount: " + request.getAmount() + ", currency: " + request.getCurrency().getCurrencyCode() + ", merchant: " + result.getMerchantId());
        } else {
            // transaction failed
            showErrorMessage("Deposit failed.", result);
        }
        transactionReferences = null;
    }

    private void onTokenComplete(TransactionResult result, TokenRequest request) {
        if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
            TransactionReferences refs = result.getTransactionReferences();
            TransactionReferenceCode code = refs.getTransactionReferenceCode("token");
            if(code != null) {
                showMessage("Token completed. Token returned: " + code.getValue());
            } else {
                showErrorMessage("Token request failed: no token.", result);
            }
        } else {
            // transaction failed
            showErrorMessage("Token request failed.", result);
        }
        transactionReferences = null;
    }

    /**
     * Shows a Toast success message with the given string
     *
     * @param text the text to show
     */
    private void showMessage(String text) {
        Log.i(TAG, text);
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    /**
     * Shows a Toast error message with the given string
     *
     * @param text   the text to show
     * @param result the transaction to pick the details from
     */
    private void showErrorMessage(String text, TransactionResult result) {
        String message = text + ". Reason: " + result.getTransactionStatus() + " - " + result.getTransactionErrorCode();
        Log.e(TAG, message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private List<Currency> getCurrencies(PaymentAppConfiguration configuration) {
        // Get the payment application configuration information.
        List<Currency> currencies = new ArrayList<Currency>(Arrays.asList(configuration.getSupportedCurrencies()));
        return currencies;
    }

    private Currency getDefaultCurrency(PaymentAppConfiguration configuration) {

          return configuration.getDefaultCurrency();
    }

    private class CurrencyListAdapter extends BaseAdapter {


        private final List<Currency> elements;

        public CurrencyListAdapter(List<Currency> elements) {
            this.elements = elements;
        }

        @Override
        public int getCount() {
            return elements.size();
        }

        @Override
        public Object getItem(int position) {
            return elements.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView textView = new TextView(parent.getContext());
            textView.setText(elements.get(position).getCurrencyCode());
            textView.setPadding(10, 10, 10, 10);
            return textView;
        }
    }

    private void setButtonState() {

        Button compButton = (Button) findViewById(R.id.completion_button);
        if(transactionReferences != null && lastTxType == TransactionType.PRE_AUTHORISATION) {
            Log.d(TAG, "Last transaction was pre-auth so enable complete button");
            compButton.setEnabled(true);
        } else {
            Log.d(TAG, "Last transaction was not pre-auth so disable complete button");
            compButton.setEnabled(false);
        }

        Button revButton = (Button) findViewById(R.id.reversal_button);
        if(transactionReferences == null) {
            Log.d(TAG, "No transaction references so cannot reverse");
            revButton.setEnabled(false);
        } else {
            Log.d(TAG, "Got a transaction reference so can reverse");
            revButton.setEnabled(true);
        }
    }

    private void checkStatus(PaymentAppConfiguration paymentAppConfiguration) {

        boolean intMode = paymentAppConfiguration.isIntegratedMode();

        TextView txtIntMode = (TextView)findViewById(R.id.integrated_mode);
        txtIntMode.setText(intMode ? getString(R.string.text_integrated_mode) : getString(R.string.text_standalone_mode));

        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button1), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button1chip), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button1visa), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button1savings), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button2), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button3), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button4), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.payment_button5), paymentAppConfiguration.isPaymentApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.refund_button), paymentAppConfiguration.isRefundRequestApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.moto_payment_button), paymentAppConfiguration.isMoToRequestApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.moto_refund_button), paymentAppConfiguration.isMoToRefundRequestApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.pre_auth_button), paymentAppConfiguration.isPreAuthorisationApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.completion_button), paymentAppConfiguration.isPreAuthorisationApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.deposit_button), paymentAppConfiguration.isDepositApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.reversal_button), paymentAppConfiguration.isReversalApiUsable() && !intMode);
        ButtonUtil.updateButton((Button) findViewById(R.id.token_button), paymentAppConfiguration.isTokenApiUsable() && !intMode);

    }

}
 