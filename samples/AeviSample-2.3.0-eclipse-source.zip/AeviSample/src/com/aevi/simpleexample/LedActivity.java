/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided "as is" and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.simpleexample;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.aevi.configuration.TerminalConfiguration;
import com.aevi.helpers.services.AeviServiceConnectionCallback;
import com.aevi.led.LedPhase;
import com.aevi.led.LedSequenceParams;
import com.aevi.led.LedService;
import com.aevi.led.LedServiceProvider;

public class LedActivity extends Activity {

    private LedServiceProvider ledServiceProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_led);

        final Switch holdSwitch = (Switch) findViewById(R.id.led_hold_final_colour);
        final Switch repeatSwitch = (Switch) findViewById(R.id.led_sequence_repeat);
        holdSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    // force repeat to off if hold is set to on
                    repeatSwitch.setChecked(false);
                }
            }
        });
        repeatSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    // force hold to off if repeat is set to on
                    holdSwitch.setChecked(false);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ledServiceProvider = new LedServiceProvider(this);
    }

    @Override
    protected void onPause() {
        // close all services and remove listeners
        ledServiceProvider.close();
        ledServiceProvider = null;
        super.onPause();
    }

    public void enableRainbowLed(View view) {
        ledServiceProvider.connect(new AeviServiceConnectionCallback<LedService>() {
            @Override
            public void onConnect(LedService service) {

                LedPhase[] phases = new LedPhase[5];
                int rate = getSelectedLedRate();
                phases[0] = new LedPhase(Color.RED, rate);
                phases[1] = new LedPhase(Color.YELLOW, rate);
                phases[2] = new LedPhase(Color.GREEN, rate);
                phases[3] = new LedPhase(Color.BLUE, rate);
                phases[4] = new LedPhase(Color.WHITE, rate);

                LedSequenceParams params = new LedSequenceParams(getRepeat(), getHoldFinalColour());
                service.setLedSequence(phases, params);
            }
        });
    }

    public void enableBlinkingLed(View view) {
        if (!validateApiIsUsable()) {
            return;
        }

        ledServiceProvider.connect(new AeviServiceConnectionCallback<LedService>() {
            @Override
            public void onConnect(LedService service) {

                LedPhase[] phases = new LedPhase[6];
                int rate = getSelectedLedRate();
                phases[0] = new LedPhase(Color.TRANSPARENT, rate);
                phases[1] = new LedPhase(getSelectedLedColour(), rate);
                phases[2] = new LedPhase(Color.TRANSPARENT, rate);
                phases[3] = new LedPhase(getSelectedLedColour(), rate);
                phases[4] = new LedPhase(Color.TRANSPARENT, rate);
                phases[5] = new LedPhase(getSelectedLedColour(), rate);

                LedSequenceParams params = new LedSequenceParams(getRepeat(), getHoldFinalColour());
                service.setLedSequence(phases, params);
            }
        });
    }

    private int getSelectedLedColour() {
        Spinner spinner = (Spinner) findViewById(R.id.led_colour_spinner);

        // Must match the colour order in R.string.led_example_colours
        int[] colourChoice = {Color.RED, Color.GREEN, Color.BLUE, Color.WHITE};
        int itemPosition = spinner.getSelectedItemPosition();
        if (itemPosition >= 0 && itemPosition < colourChoice.length) {
            return colourChoice[itemPosition];
        }
        return Color.WHITE;
    }

    private int getSelectedLedRate() {
        Spinner spinner = (Spinner) findViewById(R.id.led_rate_spinner);

        // Must match the rates given in R.string.led_example_rates
        int[] rates = {100, 200, 500, 1000};
        int itemPosition = spinner.getSelectedItemPosition();
        if (itemPosition >= 0 && itemPosition < rates.length) {
            return rates[itemPosition];
        }
        return 100;
    }

    private boolean getRepeat() {
        Switch rSwitch = (Switch) findViewById(R.id.led_sequence_repeat);
        return rSwitch.isChecked();
    }

    private boolean getHoldFinalColour() {
        Switch rSwitch = (Switch) findViewById(R.id.led_hold_final_colour);
        return rSwitch.isChecked();
    }

    public void disableBlinkingLed(View view) {
        if (!validateApiIsUsable()) {
            return;
        }

        ledServiceProvider.connect(new AeviServiceConnectionCallback<LedService>() {
            @Override
            public void onConnect(LedService service) {
                service.cancel();
            }
        });
    }

    public void setLedColour(View view) {
        if (!validateApiIsUsable()) {
            return;
        }

        int col = Color.TRANSPARENT;
        switch(view.getId()) {
            case R.id.led_colour_white: {
                col = Color.WHITE;
                break;
            }
            case R.id.led_colour_red: {
                col = Color.RED;
                break;
            }
            case R.id.led_colour_blue: {
                col = Color.BLUE;
                break;
            }
            case R.id.led_colour_green: {
                col = Color.GREEN;
                break;
            }
            case R.id.led_colour_clear: {
                col = Color.TRANSPARENT;
                break;
            }
        }

        final int ledcolour = col;
        ledServiceProvider.connect(new AeviServiceConnectionCallback<LedService>() {
            @Override
            public void onConnect(LedService service) {
                service.setLedColour(ledcolour);
            }
        });
    }

    // checkStatus

    private boolean validateApiIsUsable() {
        TerminalConfiguration terminalConfiguration = TerminalConfiguration.getTerminalConfiguration(this);
        if (!terminalConfiguration.isLedApiUsable()) {
            Toast.makeText(this, "LED API does not work. Reason : " + terminalConfiguration.getLedApiStatus(), Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

}
