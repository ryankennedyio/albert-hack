/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.adapters;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.aevi.barposexample.model.Bill;
import com.aevi.barposexample.model.Item;
import com.aevi.barposexample.views.BillItemView;

/**
 * Adapter that exposes the items on a bill. The adapter creates {@link BillItemView} views to display individual items.
 */
public class BillAdapter extends BaseAdapter {

    // Android context, for creating views
    private final Context context;

    // The bill this adapter is exposing
    private final Bill bill;

    // A click listener for the remove button.
    private final OnClickListener removeClickListener;

    /**
     * Constructs a new {@link BillAdapter}.
     *
     * @param context             Android {@link Context} object
     * @param bill                the bill to expose
     * @param removeClickListener click listener for the remove button
     */
    public BillAdapter(Context context, Bill bill, OnClickListener removeClickListener) {
        this.context = context;
        this.bill = bill;
        this.removeClickListener = removeClickListener;
    }

    @Override
    public int getCount() {
        return bill.getItems().size();
    }

    @Override
    public Object getItem(int position) {
        return bill.getItems().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BillItemView ret = null;
        Item item = bill.getItems().get(position);

        if (convertView == null) {
            ret = new BillItemView(context, item, position, removeClickListener);
        } else {
            ret = (BillItemView) convertView;
            ret.setItem(item, position);
        }

        return ret;
    }

}
