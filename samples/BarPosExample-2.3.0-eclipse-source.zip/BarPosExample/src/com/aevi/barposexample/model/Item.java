/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.model;

import java.math.BigDecimal;

/**
 * An item (usually a drink) that can be purchased by customers.
 */
public class Item {

    // Item name (i.e. 'Westvleteren 12')
    private final String name;

    // Price (i.e. 2.50)
    private final BigDecimal price;

    // Resource ID for an image of the product
    private final int resourceId;

    /**
     * Constructs a new item with a given name, price, and resource ID.
     *
     * @param name       item name (i.e. 'Westvleteren 12')
     * @param price      price (i.e. 2.50)
     * @param resourceId resource ID for an image of the product
     */
    public Item(String name, BigDecimal price, int resourceId) {
        this.name = name;
        this.price = price;
        this.resourceId = resourceId;
    }

    /**
     * Constructs a new item with a given name, price, and resource ID.
     *
     * @param name       item name (i.e. 'Westvleteren 12')
     * @param price      price (i.e. 2.50). The string is parsed into a BigDecimal.
     * @param resourceId resource ID for an image of the product
     */
    public Item(String name, String price, int resourceId) {
        this(name, new BigDecimal(price), resourceId);
    }

    /**
     * Gets the name of the item (i.e. 'Westvleteren 12').
     *
     * @return item name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the price of the item (i.e. '2.50').
     *
     * @return item price
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Gets a resource ID for a {@link drawable} of this item.
     *
     * @return a resource ID for a {@link drawable} of this item.
     */
    public int getResourceId() {
        return resourceId;
    }
}
