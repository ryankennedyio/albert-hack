/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Drinks are organized into categories. Each category has a button on the product selection screen.
 */
public class Category {

    // List of items in this category
    private final List<Item> items = new ArrayList<Item>();

    // Category name
    private final String name;

    /**
     * Constructs a new category
     *
     * @param name category name
     */
    public Category(String name) {
        this.name = name;
    }

    /**
     * Gets a list of items in the category.
     *
     * @return a list of {@link Item} objects in this category.
     */
    public List<Item> getItems() {
        return items;
    }

    /**
     * Gets the category name.
     *
     * @return category name
     */
    public String getName() {
        return name;
    }

    /**
     * Adds an {@link Item} to the category.
     *
     * @param item {@link Item} to add. This parameter must not be null.
     * @return {@link Category} object so that calls can be 'chained'/
     */
    public Category addItem(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("item must not be null");
        }
        items.add(item);
        return this;
    }
}
