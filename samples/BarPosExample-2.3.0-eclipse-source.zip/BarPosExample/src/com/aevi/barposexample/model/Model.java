/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.model;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

/**
 * The main model for our bar. This includes drinks grouped into categories, tables, and bills for each table.
 */
public class Model {

    // List of tables in the restaurant
    private final List<Table> tables = new ArrayList<Table>();

    // List of categories. These contain the items that can be ordered.
    private final List<Category> categories = new ArrayList<Category>();

    // Currency to pay in (i.e. USD, EUR, AUD, etc.)
    private final Currency currency;

    /**
     * Constructs a new instance of the bar model.
     *
     * @param currency currency to pay in (i.e. USD, EUR, AUD, etc.)
     */
    public Model(Currency currency) {
        this.currency = currency;
    }

    /**
     * Adds a table to the model.
     *
     * @param table table to add
     */
    public void addTable(Table table) {
        this.tables.add(table);
    }

    /**
     * Gets a list of tables in the model.
     *
     * @return list of tables in the model.
     */
    public List<Table> getTables() {
        return tables;
    }

    /**
     * Adds a category to the model.
     *
     * @param category category to add
     */
    public void addCategory(Category category) {
        categories.add(category);
    }

    /**
     * Gets a list of categories in the model.
     *
     * @return list of categories in the model.
     */
    public List<Category> getCategories() {
        return categories;
    }

    /**
     * Finds a category by name.
     *
     * @param name category name
     * @return category object if found, or null otherwise
     */
    public Category getCategoryByName(String name) {
        for (Category category : categories) {
            if (category.getName().equals(name)) {
                return category;
            }
        }

        return null;
    }

    /**
     * Gets the currency used for payment in this bar. We assume only a single currency is used.
     *
     * @return
     */
    public Currency getCurrency() {
        return currency;
    }

}
