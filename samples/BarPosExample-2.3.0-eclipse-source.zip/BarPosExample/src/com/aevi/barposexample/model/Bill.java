/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * A bill for single table. Contains an ordered list of drinks that have been ordered. Drinks are not 'grouped', so if
 * one orders two draft beers, it will be stored as two entries for a single draft beer.
 */
public class Bill {

    // Items on the bill
    private final List<Item> items = new ArrayList<Item>();

    /**
     * Constructs a new, empty bill.
     */
    protected Bill() {
    }

    /**
     * Gets
     *
     * @return true iff the bill is empty (zero items).
     */
    public boolean isEmpty() {
        return items.size() == 0;
    }

    /**
     * Returns the number of drinks on the bill.
     *
     * @return number of drinks on the bill
     */
    public int getItemCount() {
        return items.size();
    }

    /**
     * Adds a new drink to the bill.
     *
     * @param item
     */
    public void addItem(Item item) {
        items.add(item);
    }

    /**
     * Returns the items that are on the bill.
     *
     * @return list of items on the bill
     */
    public List<Item> getItems() {
        return items;
    }

    /**
     * Removes an item from the bill.
     *
     * @param index item to remove
     */
    public void removeItem(int index) {
        if (index < 0) {
            throw new IllegalArgumentException("Index may not be less than zero");
        }
        if (index >= items.size()) {
            throw new IllegalArgumentException("Index may not exceed item count");
        }

        items.remove(index);
    }

    /**
     * Gets the total amount of all the items on the bill.
     *
     * @return the total amount of all the items on the bill
     */
    public BigDecimal getTotalAmount() {
        BigDecimal ret = BigDecimal.ZERO;

        for (Item item : items) {
            ret = ret.add(item.getPrice());
        }

        return ret;
    }

}
