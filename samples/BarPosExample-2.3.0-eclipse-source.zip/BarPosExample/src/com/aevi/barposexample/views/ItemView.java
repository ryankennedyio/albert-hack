/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided "as is" and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.views;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aevi.barposexample.R;
import com.aevi.barposexample.model.Item;
import com.aevi.barposexample.model.Model;

/**
 * Draws the name and price of a beer in our POS application
 */
public class ItemView extends LinearLayout {

    private Item item;
    private Model model;
    private TextView nameText;
    private TextView priceText;

    /**
     * Construct a new instance of {@Plink ItemView}
     *
     * @param context the Android context
     * @param model   the Bar POS model
     * @param item    the item to draw
     */
    public ItemView(Context context, Model model, Item item) {
        super(context);
        this.model = model;
        this.item = item;

        setFocusable(true);
        setClickable(true);

        setOrientation(LinearLayout.VERTICAL);

        nameText = new TextView(context);
        nameText.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1));
        nameText.setHeight(100);
        nameText.setTextSize(20);
        nameText.setTextColor(Color.BLACK);
        nameText.setGravity(Gravity.CENTER);
        addView(nameText);

        priceText = new TextView(context);
        priceText.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 0));
        priceText.setHeight(40);
        priceText.setTextSize(16);
        priceText.setTextColor(Color.BLACK);
        priceText.setGravity(Gravity.CENTER);
        addView(priceText);

        setBackgroundColor(Color.WHITE);

        setBackgroundDrawable(context.getResources().getDrawable(R.drawable.item_button));

        redraw();
    }

    /**
     * Set the item associated with this instance
     *
     * @param item the item
     */
    public void setItem(Item item) {
        this.item = item;
        redraw();
    }

    /**
     * Get the item associated with this instance
     *
     * @return the item
     */
    public Item getItem() {
        return item;
    }

    /**
     * Redraw the text of the item view
     */
    private void redraw() {
        nameText.setText(item.getName());
        priceText.setText(model.getCurrency().getSymbol() + " " + item.getPrice().toPlainString());
    }
}
