/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import com.aevi.barposexample.adapters.BillAdapter;
import com.aevi.barposexample.adapters.CategoryAdapter;
import com.aevi.barposexample.adapters.ItemAdapter;
import com.aevi.barposexample.model.Category;
import com.aevi.barposexample.model.Item;
import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.model.Table;
import com.aevi.barposexample.views.BillItemView;
import com.aevi.barposexample.views.ItemView;

import java.math.BigDecimal;

/**
 * This activity is shown when the user selects a table and brings up the current bill of that table. Items, grouped
 * into categories, can be added to the bill, and items can be removed from the bill.
 */
public class ItemSelectionActivity extends Activity {

    // Application model
    private Model model;

    // The table whose bill we are showing in this activity
    private Table table;

    // Adapter for the bill of the table.
    private BillAdapter billAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialise UI
        setContentView(R.layout.activity_item_selection);

        // Get the application data model
        model = ((BarPosApplication) getApplication()).getModel();

        // Set the grid view adapter to display the categories tables
        GridView gridView = (GridView) findViewById(R.id.categoryButtonGridView);
        gridView.setAdapter(new CategoryAdapter(this, model.getCategories(), categoryClickListener));
    }

    @Override
    protected void onStart() {
        super.onStart();

        int tableNumber = getIntent().getIntExtra(BarPosApplication.TABLE_KEY, 0);

        table = model.getTables().get(tableNumber);

        if (model.getCategories().size() > 0) {
            selectCategory(model.getCategories().get(0));
        }

        // Set the grid view adapter to display the available tables
        ListView billView = (ListView) findViewById(R.id.billView);
        billAdapter = new BillAdapter(this, table.getBill(), removeBillItemClickListener);
        billView.setAdapter(billAdapter);

        updateBillView();
    }

    // Updates the bill view on the bottom of the screen after the bill has been modified.
    private void updateBillView() {
        // Notify the bill adapter, this updates the list view that shows the list of items on the bill.
        billAdapter.notifyDataSetChanged();

        // Scroll the view to the last item
        ListView billView = (ListView) findViewById(R.id.billView);
        billView.setSelection(billAdapter.getCount() - 1);

        // Update total
        TextView totalAmountView = ((TextView) findViewById(R.id.totalAmount));
        totalAmountView.setText(model.getCurrency().getSymbol() + " " + table.getBill().getTotalAmount());

        // Enable/disable the pay button
        ((Button) findViewById(R.id.payButton)).setEnabled(table.getBill().getTotalAmount().compareTo(BigDecimal.ZERO) > 0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.table_selection, menu);
        return true;
    }

    private void selectCategory(Category category) {
        // Get the grid view that holds the item buttons
        GridView gridView = (GridView) findViewById(R.id.itemButtonGridView);

        // Set a new grid view adapter to update the category
        gridView.setAdapter(new ItemAdapter(this, model, category, itemClickListener));
    }

    /**
     * Go back to the previous screen
     *
     * @param view the clicked view
     */
    public void onBackClick(View view) {
        finish();
    }

    /**
     * Pay the bill
     *
     * @param view the clicked view
     */
    public void onPayClick(View view) {
        // Let the PaymentActivity handle the payment.
        Intent intent = new Intent(this, PaymentActivity.class);
        intent.putExtra(BarPosApplication.TABLE_KEY, table.getTableNumber());
        startActivity(intent);
    }

    // Handles click event from the category buttons along the top of the screen
    private OnClickListener categoryClickListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            // Get the category from the model
            Category category = model.getCategoryByName(((Button) view).getText().toString());

            // Select the category
            selectCategory(category);
        }
    };

    // Called when the user clicks one of the item buttons.
    private OnClickListener itemClickListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            // Get item from the button
            Item item = ((ItemView) view).getItem();

            // Add the item to the table's bill
            table.getBill().addItem(item);

            // Update the UI
            updateBillView();
        }
    };

    // Called when the user selects one of the remove buttons in the bill. Removes the corresponding item from the bill.
    private OnClickListener removeBillItemClickListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            // Get the bill item's index
            int index = ((BillItemView) view.getParent()).getItemIndex();

            // Remove the item from the bill
            table.getBill().removeItem(index);

            // Update the UI
            updateBillView();
        }
    };
}
