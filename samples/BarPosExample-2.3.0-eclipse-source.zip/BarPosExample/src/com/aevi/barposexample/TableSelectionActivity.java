/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party.
 */
package com.aevi.barposexample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.aevi.barposexample.adapters.TableAdapter;
import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.model.Table;
import com.aevi.barposexample.views.TableView;

import com.aevi.payment.PaymentAppConfiguration;
import com.aevi.payment.PaymentAppConfigurationRequest;

import com.aevi.helpers.ServiceState;

/**
 * The {@link TableSelectionActivity} shows a grid of tables. Each table has a unique number, which is used by servers
 * to identify that table. Each table has a bill associated with it, and when that bill is non-empty, the total amount
 * of the bill is shown. Selecting a table will bring up the {@link ItemSelectionActivity} screen, which provides a way
 * to mutate the bill, or proceed to payment.
 */
public class TableSelectionActivity extends Activity {

    private static final String TAG = TableSelectionActivity.class.getSimpleName();

    // Adapter for the set of tables on screen.
    private TableAdapter tableAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialise UI
        setContentView(R.layout.activity_table_selection);

        // Ensure the payment application/simulator is installed. If not, present an alert dialog
        // to the user and exit.
        ServiceState paymentAppState = PaymentAppConfiguration.getPaymentApplicationStatus(this);
        Log.d(TAG, "Payment App State: " + paymentAppState);
        if (paymentAppState == ServiceState.NOT_INSTALLED) {
            showExitDialog("A payment application is not installed.\n This application will now exit.");
        } else if (paymentAppState == ServiceState.NO_PERMISSION) {
            showExitDialog("A payment application installed but this App does not have the permission to use it.\n This application will now exit.");
        } else if (paymentAppState == ServiceState.UNAVAILABLE) {
            showExitDialog("The payment application is unavailable.\n This application will now exit.");
        } else {
            // fetch the Payment App Configuration
            fetchPaymentAppConfiguration();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.table_selection, menu);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Must check if Payment Configuration is initialised...
        if (BarPosApplication.getPaymentAppConfiguration() != null) {
            // Create a selection button for each of the tables
            Model model = ((BarPosApplication) getApplication()).getModel();

            // Set the grid view adapter to display the available tables
            GridView gridView = (GridView) findViewById(R.id.tableButtonGridView);
            tableAdapter = new TableAdapter(this, model, tableClickListener);
            gridView.setAdapter(tableAdapter);

            // The bill may have been modified or paid, so we have to update the grid view to reflect the changes
            tableAdapter.notifyDataSetChanged();
        }
    }

    private OnClickListener tableClickListener = new OnClickListener() {
        @Override
        public void onClick(View view) {
            // Get the Table instance from the view
            Table table = ((TableView) view).getTable();

            // Start the ItemSelectionActivity, passing in the table number
            Intent startIntent = new Intent(TableSelectionActivity.this, ItemSelectionActivity.class);
            startIntent.putExtra(BarPosApplication.TABLE_KEY, table.getTableNumber());
            startActivity(startIntent);
        }
    };

    /**
     * fetch the Payment Configuration
     */
    private void fetchPaymentAppConfiguration() {
        startActivityForResult(PaymentAppConfigurationRequest.createIntent(), 0);
    }

    /**
     * Called by Android when the control returns to this activity.
     *
     * @param requestCode the code associated with the request (0)
     * @param resultCode  the Intent result code
     * @param data        the result data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0 && resultCode == Activity.RESULT_OK) {

            // Save the Payment Configuration in the Application Object
            PaymentAppConfiguration paymentAppConfiguration = PaymentAppConfiguration.fromIntent(data);
            BarPosApplication barPosApplication = (BarPosApplication) getApplication();
            barPosApplication.setPaymentAppConfiguration(paymentAppConfiguration);
        }
        else {
            showExitDialog("There was a problem obtaining the PaymentAppConfiguration object.\n This application will now exit.");
        }
    }

    private void showExitDialog(String messageStr) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        TextView textView = new TextView(this);
        textView.setText(messageStr);
        textView.setGravity(Gravity.CENTER_HORIZONTAL);
        builder.setView(textView);
        builder.setPositiveButton("Ok", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).setCancelable(false);
        AlertDialog alert = builder.create();
        alert.show();
    }
}