package com.aevi.tothemovies.classic;

import android.content.Context;

/**
 * The Uri Builder class is able to create uris for rest api and for image downloading taking into account if it is running on a
 * an Aevi device (or emulator) or not.
 */
public class TheMovieDBUriBuilder {

    private static final String API_URL = "https://api.themoviedb.org/3";
    private static final String API_KEY = "b4b100d1055bb5ec2219ed64270ab0d7";
    private final Context context;


    public TheMovieDBUriBuilder(Context context) {
        this.context = context;
    }

    /**
     * Create an uri for downloading images
     *
     * @param uri the uri where the image is located
     * @return the uri that is rewritten when necessary
     */
    public String createImageUri(String uri) {
        return addApiKey(uri);
    }

    /**
     * Create an uri for accessing the themoviedb rest api.
     *
     * @param fraction The rest path and parameters
     * @return the full uri taking into account if it is used on a aevi device or emulator or on a regular android platform
     */
    public String createApiUri(String fraction) {

        return addApiKey(API_URL + fraction);
    }

    /**
     * Add the api key to a rest request
     *
     * @param uri the uri without the api key parameter
     * @return the uri with the uri parameter
     */
    private String addApiKey(String uri) {
        return uri + "?api_key=" + API_KEY;
    }

}
