package com.aevi.tothemovies.classic;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The adapter used to display the list of currently playing movies in the grid view
 */
public class MovieAdapter extends BaseAdapter {

    private final Context context;
    private final List<Movie> movies;

    private final Map<Integer, Bitmap> cache = new HashMap<Integer, Bitmap>();

    public MovieAdapter(List<Movie> movies, Context context) {
        this.context = context;
        this.movies = movies;
    }

    @Override
    public int getCount() {
        return movies.size();
    }

    @Override
    public Object getItem(int position) {
        return movies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return movies.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //create a new ImageView for each item referenced by the Adapter
        final Movie movie = movies.get(position);
        final ImageView imageView = new ImageView(context);
        if (cache.containsKey(movie.getId())) {
            imageView.setImageBitmap(cache.get(movie.getId()));
        } else {

            new ReadImageTask() {
                @Override
                protected void onPostExecute(Bitmap result) {
                    cache.put(movie.getId(), result);
                    imageView.setImageBitmap(result);
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, movie.getPosterUrl());
        }
        return imageView;
    }
}
