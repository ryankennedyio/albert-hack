package com.aevi.tothemovies.classic;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

/**
 * Base class for retrieving images for a given url. When implementing the onPostExecute method should be
 * implemented to handle the results.
 * <p/>
 * example :
 * <p/>
 * new ReadImageTask() {
 *
 * @Override protected void onPostExecute(Bitmap result) {
 * //handle result on main thread
 * }
 * }.execute("http://imgur.com/gallery/bODu3Fz");
 */
public abstract class ReadImageTask extends AsyncTask<String, String, Bitmap> {

    private static final String TAG = ReadImageTask.class.getSimpleName();

    @Override
    protected Bitmap doInBackground(String... urls) {
        Log.d(TAG, "Reading image:" + urls[0]);
        Bitmap bitmap = null;
        InputStream in = null;
        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(new URI(urls[0]));
            HttpResponse response = client.execute(request);
            in = response.getEntity().getContent();
            bitmap = BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            Log.e(TAG, "Error on reading image:" + urls[0], e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    Log.e(TAG, "Error on closing the stream", e);
                }
            }

        }
        return bitmap;
    }
}
