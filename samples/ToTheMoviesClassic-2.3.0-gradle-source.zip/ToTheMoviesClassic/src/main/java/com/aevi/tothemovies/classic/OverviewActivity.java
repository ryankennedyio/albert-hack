/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party.
 */
package com.aevi.tothemovies.classic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.aevi.configuration.TerminalConfiguration;
import com.aevi.helpers.CompatibilityException;
import com.aevi.helpers.ServiceState;
import com.aevi.helpers.StringUtils;
import com.aevi.payment.PaymentAppConfiguration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Shows the list of currently playing movies in a gridview
 */
public class OverviewActivity extends Activity {

    private static final String TAG = OverviewActivity.class.getSimpleName();

    private String baseImageUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_overview);

        // Check if TerminalServices are installed
        try {
            if (TerminalConfiguration.isTerminalServicesInstalled(this) == false) {
                showExitDialog("Terminal Services is not installed or installed incorrectly.\nThis application will now exit.");
                return;
            }
        } catch(CompatibilityException e) {
            showExitDialog(e.getMessage() + "\nThis application will now exit.");
            return;
        }

        ((MainApplication) getApplication()).setUriBuilder(new TheMovieDBUriBuilder(this));

        // Ensure the payment application/simulator is installed. If not, present an alert dialog
        // to the user and exit.
        ServiceState paymentAppState = PaymentAppConfiguration.getPaymentApplicationStatus(this);
        Log.d(TAG, "Payment App State: " + paymentAppState);

        if (paymentAppState == ServiceState.NOT_INSTALLED) {
            showExitDialog("A payment application is not installed.\n This application will now exit.");
        } else if (paymentAppState == ServiceState.NO_PERMISSION) {
            showExitDialog("A payment application installed but this App does not have the permission to use it.\n This application will now exit.");
        } else if (paymentAppState == ServiceState.UNAVAILABLE) {
            showExitDialog("The payment application is unavailable.\n This application will now exit.");
        }

        loadConfiguration();
    }

    private void loadConfiguration() {
        new ReadJsonTask() {
            @Override
            protected void onPostExecute(JSONArray result) {
                try {
                    if (result == null || result.length() != 1) {
                        showConnectionErrorDialog();
                    } else {
                        JSONObject json = (JSONObject) result.get(0);
                        baseImageUrl = json.getJSONObject("images").getString("secure_base_url");
                        loadMovieList(baseImageUrl);
                    }
                } catch (JSONException e) {
                    Log.e(TAG, "Error when loading configuration", e);
                }

            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, uriBuilder().createApiUri("/configuration"));
    }

    private void showExitDialog(String messageStr) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        TextView textView = new TextView(this);
        textView.setText(messageStr);
        textView.setGravity(Gravity.CENTER_HORIZONTAL);
        builder.setView(textView);
        builder.setPositiveButton("Ok", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).setCancelable(false);
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void showConnectionErrorDialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Error on load");
        alertDialog.setMessage("There was a problem downloading information from the moviedb.org. " +
                "There might be problems with the service or your internet connection. " +
                "Please try again later.");
        alertDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        alertDialog.setIcon(R.drawable.aevi_icon);
        alertDialog.show();
    }

    private void loadMovieList(final String imageBaseUrl) {
        new ReadJsonTask() {
            @Override
            protected void onPostExecute(JSONArray result) {
                if (result == null || result.length() != 1) {
                    showConnectionErrorDialog();
                } else {
                    List<Movie> movies = new ArrayList<Movie>();
                    try {
                        JSONObject json = (JSONObject) result.get(0);
                        JSONArray jsonMovies = json.getJSONArray("results");
                        for (int j = 0; j < jsonMovies.length(); j++) {
                            Movie movie = new Movie((JSONObject) jsonMovies.get(j), imageBaseUrl, OverviewActivity.this.uriBuilder());
                            Log.i(TAG, movie.toString());
                            if (StringUtils.isNotBlank(movie.getBackgroundUrl()) && !movie.isAdult()) {
                                movies.add(movie);
                            }
                        }
                        updateScreen(movies);
                    } catch (JSONException e) {
                        Log.e(TAG, "Error when loading movie list", e);
                    }
                }
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, uriBuilder().createApiUri("/movie/now_playing"));
    }

    private TheMovieDBUriBuilder uriBuilder() {
        return ((MainApplication) getApplication()).getUriBuilder();
    }

    private void updateScreen(final List<Movie> movies) {
        GridView gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new MovieAdapter(movies, this));
        gridview.refreshDrawableState();
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Movie movie = movies.get(position);
                Intent startIntent = new Intent(OverviewActivity.this, DetailActivity.class);
                startIntent.putExtra("id", movie.getId());
                startIntent.putExtra("baseImageUrl", baseImageUrl);
                startActivity(startIntent);
            }
        });
    }

}