package com.aevi.tothemovies;

public class DefaultCurrencyNotSetException extends RuntimeException {
}
