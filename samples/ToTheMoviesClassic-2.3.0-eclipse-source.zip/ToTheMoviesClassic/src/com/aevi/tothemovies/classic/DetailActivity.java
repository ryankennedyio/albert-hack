/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party.
 */
package com.aevi.tothemovies.classic;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.aevi.payment.PaymentAppConfiguration;
import com.aevi.payment.PaymentAppConfigurationRequest;
import com.aevi.payment.PaymentRequest;
import com.aevi.payment.TransactionResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Activity for showing the details of the selected movie
 */
public class DetailActivity extends Activity {

    private static final String TAG = DetailActivity.class.getSimpleName();

    private static final int REQUEST_CONFIGURATION = 1;
    private static final int REQUEST_PAYMENT = 2;
    private static final int REQUEST_RESULT = 3;

    private Movie movie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        fetchPaymentAppConfiguration();

    }

    private void fetchPaymentAppConfiguration() {
        startActivityForResult(PaymentAppConfigurationRequest.createIntent(), REQUEST_CONFIGURATION);
    }


    private void fetchMovieDetails(final PaymentAppConfiguration paymentAppConfiguration) {
        final Integer id = getIntent().getIntExtra("id", -1);
        final String baseImageUrl = getIntent().getStringExtra("baseImageUrl");
        if (id == -1) {
            return;
        }

        new ReadJsonTask() {
            @Override
            protected void onPostExecute(JSONArray result) {
                try {
                    DetailActivity.this.movie = new Movie((JSONObject) result.get(0), baseImageUrl, uriBuilder());
                    updateDetailInformation(movie, paymentAppConfiguration);
                } catch (JSONException e) {
                    Log.e(TAG, "Error occurred during the retrieval of the movie details", e);
                }
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, uriBuilder().createApiUri("/movie/" + id));
    }

    private void updateDetailInformation(Movie movie, final PaymentAppConfiguration paymentAppConfiguration) {
        ((TextView) findViewById(R.id.title)).setText(movie.getTitle());
        ((TextView) findViewById(R.id.description)).setText(movie.getOverview());
        updateBackgroundImage(movie);
        updatePosterImage(movie);
        String currencySymbol = paymentAppConfiguration.getDefaultCurrency().getSymbol();
        ((TextView) findViewById(R.id.ticketPrice)).setText(currencySymbol + movie.getPrice());
        ((TextView) findViewById(R.id.bookingCosts)).setText(currencySymbol + movie.getBookingCosts());
        ((TextView) findViewById(R.id.totalPrice)).setText(currencySymbol + movie.getTotalPrice());
        ((Button) findViewById(R.id.buyTicketButton)).setEnabled(true);
    }

    private void updatePosterImage(final Movie movie) {
        new ReadImageTask() {
            @Override
            protected void onPostExecute(Bitmap result) {
                ((ImageView) findViewById(R.id.posterImage)).setImageBitmap(result);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, movie.getPosterUrl());
    }

    private void updateBackgroundImage(final Movie movie) {
        new ReadImageTask() {
            @Override
            protected void onPostExecute(Bitmap result) {
                ((ImageView) findViewById(R.id.backgroundImage)).setImageBitmap(result);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, movie.getBackgroundUrl());
    }


    private TheMovieDBUriBuilder uriBuilder() {
        return ((MainApplication) getApplication()).getUriBuilder();
    }

    /**
     * When the payment button is created for the payment application
     *
     * @param view
     */
    public void payClick(View view) {
        Log.d(TAG, "Creating a payment request for movieId:" + movie.getId() + ", amount:" + movie.getTotalPrice());
        PaymentRequest paymentRequest = new PaymentRequest(movie.getTotalPrice());
        startActivityForResult(paymentRequest.createIntent(), REQUEST_PAYMENT);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CONFIGURATION) {
            PaymentAppConfiguration paymentAppConfiguration = PaymentAppConfiguration.fromIntent(data);
            fetchMovieDetails(paymentAppConfiguration);

        } else if (requestCode == REQUEST_PAYMENT) {
            TransactionResult transactionResult = TransactionResult.fromIntent(data);

            switch (transactionResult.getTransactionStatus()) {
                case APPROVED:
                    Intent startIntent = new Intent(this, SuccessActivity.class);
                    startIntent.putExtra("name", movie.getTitle());
                    startActivityForResult(startIntent, REQUEST_RESULT);
                    break;
                default:
                    startIntent = new Intent(this, FailureActivity.class);
                    startIntent.putExtra("name", movie.getTitle());
                    startIntent.putExtra("status", transactionResult.getTransactionStatus().toString());
                    startIntent.putExtra("code", transactionResult.getTransactionErrorCode().toString());
                    startActivityForResult(startIntent, REQUEST_RESULT);
                    break;
            }
        } else if (requestCode == REQUEST_RESULT) {
            finish();
        }

    }

}