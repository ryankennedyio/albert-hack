package com.aevi.tothemovies.classic;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * Activity for showing the failure screen
 */
public class FailureActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_failure);
        String title = getIntent().getStringExtra("name");
        String status = getIntent().getStringExtra("status");
        String code = getIntent().getStringExtra("code");
        ((TextView) findViewById(R.id.failureMessage)).setText("Something went wrong with your payment for \"" + title + "\" and we can't print your ticket.\n\nThe Status is:  " + status + ".\n\nThe Error code is: " + code + ".");
    }

    /**
     * Closing the screen and going back to the list of current movies
     *
     * @param view
     */
    public void backToListClick(View view) {
        finish();
    }


}
