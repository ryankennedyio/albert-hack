package com.aevi.tothemovies.classic;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

/**
 * Base class for doing json get requests request. When implementing the onPostExecute method should be
 * implemented to handle the results.
 * <p/>
 * example :
 * <p/>
 * new ReadJsonTask() {
 *
 * @Override protected void onPostExecute(JSONArray result) {
 * //handle json result
 * }
 * }.execute("https://api.themoviedb.org/3/movie/76338?api_key=b4b100d1055bb5ec2219ed64270ab0d7");
 */
public abstract class ReadJsonTask extends AsyncTask<String, String, JSONArray> {

    private static final String TAG = ReadJsonTask.class.getSimpleName();

    @Override
    protected JSONArray doInBackground(String... urls) {
        List<JSONObject> result = new ArrayList<JSONObject>();
        for (String url : urls) {
            JSONObject object = readHttpData(url);
            if (object != null) {
                result.add(object);
            }
        }
        if (result.size() == 0) {
            return null;
        } else {
            return new JSONArray(result);
        }
    }

    private JSONObject readHttpData(String url) {
        Log.d(TAG, "Reading data from :" + url);
        JSONObject result = null;
        InputStream is = null;
        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet(new URI(url));
            HttpResponse response = client.execute(request);
            is = response.getEntity().getContent();
            result = decodeTheJsonResponse(is);
        } catch (IOException e) {
            Log.e(TAG, "Network problems", e);
        } catch (URISyntaxException e) {
            Log.e(TAG, "invalid URL", e);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    Log.e(TAG, "Error when trying to close the inputStream", e);
                }
            }
        }

        return result;
    }

    private JSONObject decodeTheJsonResponse(InputStream is) {
        String jsonString = inputStreamToString(is);
        try {
            return new JSONObject(jsonString);
        } catch (JSONException e) {
            Log.e(TAG, "Not valid json", e);
        }
        return null;
    }

    private String inputStreamToString(InputStream stream) {
        BufferedReader in = new BufferedReader(new InputStreamReader(stream));
        String result = "";
        while (true) {
            String line;
            try {
                line = in.readLine();
            } catch (IOException e) {
                break;
            }
            if (line == null) {
                break;
            }
            result += line;
        }
        return result;
    }

}
