/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided "as is" and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party.
 */
package com.aevi.tothemovies.classic;

import android.app.Application;

/**
 * The application class is used to provide general functionality to the activities.
 * In this case activities can get the default currencies and an uri builder.
 */
public class MainApplication extends Application {

    private static final String TAG = MainApplication.class.getSimpleName();

    private TheMovieDBUriBuilder uriBuilder;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public void setUriBuilder(TheMovieDBUriBuilder uriBuilder) {

        this.uriBuilder = uriBuilder;
    }

    public TheMovieDBUriBuilder getUriBuilder() {

        return uriBuilder;
    }

}

