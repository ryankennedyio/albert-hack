package com.aevi.tothemovies.classic;

import com.aevi.helpers.StringUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;

/**
 * Class containing the movie information. It can be constructed based on the json representation, the image base url and an uri builder
 */
public class Movie {

    private static final String DETAIL_IMAGE = "w342";
    private static final String BACKGROUND_IMAGE = "w780";

    private final String title;
    private final Integer id;
    private final String backgroundUrl;
    private final String posterUrl;
    private final String overview;
    private final boolean adult;

    /**
     * Construct a movie object based on the json representation, the image base url and an uri builder
     *
     * @param jsonObject   the json object as received from the to the movies api
     * @param imageBaseUrl the image base url that kan be used to load the images found in the json representation.
     * @param uriBuilder   the class able to create uris based on the given image uri
     * @throws JSONException
     */
    public Movie(JSONObject jsonObject, String imageBaseUrl, TheMovieDBUriBuilder uriBuilder) throws JSONException {
        id = jsonObject.getInt("id");
        title = jsonObject.getString("title");
        if (hasStringProperty(jsonObject, "backdrop_path")) {
            backgroundUrl = uriBuilder.createImageUri(imageBaseUrl + BACKGROUND_IMAGE + "/" + jsonObject.getString("backdrop_path"));
        } else {
            backgroundUrl = null;
        }
        posterUrl = uriBuilder.createImageUri(imageBaseUrl + DETAIL_IMAGE + "/" + jsonObject.getString("poster_path"));
        adult = jsonObject.getBoolean("adult");
        if (jsonObject.has("overview")) {
            overview = jsonObject.getString("overview");
        } else {
            overview = "";
        }
    }

    @Override
    public String toString() {
        return String.format("[%d]'%s' : %s", id, title, posterUrl);
    }

    /**
     * Returns the title of the movie
     *
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * returns the id of the movie
     *
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * returns the url of the background image
     *
     * @return
     */
    public String getBackgroundUrl() {
        return backgroundUrl;
    }

    /**
     * returns the url of the poster image
     *
     * @return
     */
    public String getPosterUrl() {
        return posterUrl;
    }


    /**
     * returns the description of the movie
     *
     * @return
     */
    public String getOverview() {
        return overview;
    }

    /**
     * returns the price of a movie ticket for this movie
     *
     * @return
     */
    public BigDecimal getPrice() {
        return new BigDecimal("15.00");
    }

    /**
     * returns the booking costs for a ticket for this movie
     *
     * @return
     */
    public BigDecimal getBookingCosts() {
        return new BigDecimal("1.50");
    }

    /**
     * returns the total price for a ticket for this movie
     *
     * @return
     */
    public BigDecimal getTotalPrice() {
        return getPrice().add(getBookingCosts());
    }

    /**
     * Indicates if the movie contains adult content
     *
     * @return
     */
    public boolean isAdult() {
        return adult;
    }

    private boolean hasStringProperty(JSONObject object, String key) {
        try {
            return object.has(key) && StringUtils.isNotBlank(object.getString(key)) && !object.getString(key).equals("null");
        } catch (JSONException e) {
            return false;
        }
    }
}
