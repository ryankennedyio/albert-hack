package com.aevi.tothemovies.classic;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.aevi.helpers.services.AeviServiceConnectionCallback;
import com.aevi.printing.PrintService;
import com.aevi.printing.PrintServiceProvider;
import com.aevi.printing.model.Alignment;
import com.aevi.printing.model.PrintPayload;

/**
 * Activity for showing the success screen and printing the receipt
 */
public class SuccessActivity extends Activity {

    private static final String TAG = SuccessActivity.class.getSimpleName();

    private PrintServiceProvider printServiceProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
        String title = getIntent().getStringExtra("name");
        printTicket(title);
        ((TextView) findViewById(R.id.successMessage)).setText("Your ticket is being printed, have fun watching \"" + title + "\".");
    }

    /**
     * Return back tot the main list view
     *
     * @param view
     */
    public void backToListClick(View view) {
        finish();
    }

    private void printTicket(final String title) {

        Log.d(TAG, "Printing ticket for event:" + title);

        if (printServiceProvider == null) {
            printServiceProvider = new PrintServiceProvider(getBaseContext());
        }

        printServiceProvider.connect(new AeviServiceConnectionCallback<PrintService>() {
            @Override
            public void onConnect(PrintService service) {

                PrintPayload ticket = new PrintPayload();
                ticket.append(title).align(Alignment.CENTER);
                ticket.appendEmptyLine();

                BitmapFactory.Options bitmapFactoryOptions = service.getDefaultPrinterSettings().asBitmapFactoryOptions();
                Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.qr_code, bitmapFactoryOptions);
                ticket.append(logo).contrastLevel(100).align(Alignment.CENTER);

                ticket.append("Please show your ticket").align(Alignment.CENTER);
                ticket.append("at the entrance of the venue").align(Alignment.CENTER);

                ticket.appendEmptyLine();
                ticket.appendEmptyLine();
                ticket.appendEmptyLine();

                try {
                    int result = service.print(ticket);
                    if (result <= 0) {
                        // handle print job failed here
                        Toast.makeText(getBaseContext(), "Failed to print ticket. Printer unavailable", Toast.LENGTH_LONG).show();
                    }
                } catch(Exception e) {
                    Toast.makeText(getBaseContext(), "Error while attempting to print ticket: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (printServiceProvider != null) {
            printServiceProvider.close();
            printServiceProvider = null;
        }
    }

}
