/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided "as is" and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.views;

import android.content.Context;
import android.graphics.Color;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aevi.barposexample.model.Item;

public class BillItemView extends LinearLayout {

    private Item item;
    private TextView name, price;
    private int itemIndex;

    public BillItemView(Context context, Item item, int itemIndex, OnClickListener removeClickListener) {
        super(context);
        this.item = item;
        this.itemIndex = itemIndex;

        setOrientation(LinearLayout.HORIZONTAL);

        this.setLayoutParams(new AbsListView.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1));

        name = new TextView(context);
        name.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1));
        name.setTextSize(18);
        name.setTextColor(Color.BLACK);
        addView(name);

        price = new TextView(context);
        price.setTextSize(18);
        price.setTextColor(Color.BLACK);
        addView(price);

        Button removeButton = new Button(context);
        removeButton.setText("X");
        removeButton.setHeight(50);
        removeButton.setWidth(50);
        removeButton.setOnClickListener(removeClickListener);
        addView(removeButton);

        setPadding(0, 0, 0, 0);

        update();
    }

    public void setItem(Item item, int itemIndex) {
        this.item = item;
        this.itemIndex = itemIndex;
        update();
    }

    public Item getItem() {
        return item;
    }

    public int getItemIndex() {
        return itemIndex;
    }

    public void update() {
        name.setText(item.getName());
        price.setText("" + item.getPrice());
    }

}
