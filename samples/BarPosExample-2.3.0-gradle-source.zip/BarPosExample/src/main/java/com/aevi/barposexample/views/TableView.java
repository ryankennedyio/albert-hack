/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided "as is" and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.util.Log;
import android.view.View;

import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.model.Table;

/**
 * Draws a bar table, complete with chairs
 */
public class TableView extends View {

    private static final String TAG = TableView.class.getSimpleName();

    private Table table;
    private Model model;
    private RectF rect = new RectF();

    private static final Paint LINE_PAINT = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint TEXT_PAINT = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint TABLE_EMPTY_PAINT = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint TABLE_NON_EMPTY_PAINT = new Paint(Paint.ANTI_ALIAS_FLAG);

    static {
        LINE_PAINT.setStyle(Style.STROKE);
        LINE_PAINT.setColor(Color.BLACK);
        LINE_PAINT.setStrokeWidth(3);

        TEXT_PAINT.setStyle(Style.FILL);
        TEXT_PAINT.setColor(Color.BLACK);

        TABLE_EMPTY_PAINT.setStyle(Style.FILL);
        TABLE_EMPTY_PAINT.setColor(Color.WHITE);

        TABLE_NON_EMPTY_PAINT.setStyle(Style.FILL);
        TABLE_NON_EMPTY_PAINT.setColor(Color.GREEN);
    }

    /**
     * Construct a new {@link TableView} instance
     *
     * @param context the Android context
     * @param model   the bar model
     * @param table   the table to draw
     */
    public TableView(Context context, Model model, Table table) {
        super(context);
        this.model = model;
        this.table = table;

        setFocusable(true);
        setClickable(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {

        Log.d(TAG, "Drawing table: " + table.getTableNumber());

        float width = getWidth();
        float height = getHeight();
        float size = Math.min(width, height);
        float tableSize = 0.25f * size;
        float chairHeight = 0.12f * size;
        float chairWidth = 0.08f * size;
        float gap = 0.03f * size;

        float textSize = size / 4.0f;
        float smallTextSize = size / 9.0f;

        int numberOfChairs = (table.getTableNumber() * 12341) % 4 + 4;

        Paint tableFillPaint = table.getBill().isEmpty() ? TABLE_EMPTY_PAINT : TABLE_NON_EMPTY_PAINT;

        // Draw table
        canvas.drawCircle(width / 2.0f, height / 2.0f, tableSize, tableFillPaint);
        canvas.drawCircle(width / 2.0f, height / 2.0f, tableSize, LINE_PAINT);

        // Draw table number
        String tableText = Integer.toString(table.getTableNumber());
        TEXT_PAINT.setTextSize(textSize);
        canvas.drawText(tableText, (width - TEXT_PAINT.measureText(tableText)) / 2, height / 2, TEXT_PAINT);

        // Draw bill amount
        String amountText = model.getCurrency().getSymbol() + " " + table.getBill().getTotalAmount();
        TEXT_PAINT.setTextSize(smallTextSize);
        canvas.drawText(amountText, (width - TEXT_PAINT.measureText(amountText)) / 2, height / 2 + smallTextSize * 1.2f, TEXT_PAINT);

        for (int i = 0; i < numberOfChairs; i++) {
            canvas.save(Canvas.MATRIX_SAVE_FLAG);

            canvas.translate(width / 2, height / 2);
            canvas.rotate(i * 360.0f / (float) numberOfChairs);

            rect.set(-chairWidth, -tableSize - chairHeight - gap, chairWidth, -tableSize - gap);

            canvas.drawRect(rect, tableFillPaint);
            canvas.drawRect(rect, LINE_PAINT);

            rect.set(-chairWidth, -tableSize - chairHeight - gap, chairWidth, -tableSize - gap - chairHeight * 0.8f);
            canvas.drawRect(rect, LINE_PAINT);

            canvas.translate(-width / 2, -height / 2);

            canvas.restore();
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(widthMeasureSpec, widthMeasureSpec);
    }

    /**
     * Set the table associated with this view
     *
     * @param table the table to set
     */
    public void setTable(Table table) {
        this.table = table;
    }

    /**
     * Gets the table associated with this view
     *
     * @return the table
     */
    public Table getTable() {
        return table;
    }

}
