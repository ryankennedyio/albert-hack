/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party.
 */
package com.aevi.barposexample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.model.Table;
import com.aevi.payment.PaymentRequest;
import com.aevi.payment.TransactionResult;
import com.aevi.payment.TransactionStatus;

import java.math.BigDecimal;

/**
 * Payment screen of the POS application
 */
public class PaymentActivity extends Activity {

    // Application model
    private Model model;

    // The table whose bill we are showing in this activity
    private Table table;

    private BigDecimal tippingAmount = BigDecimal.ZERO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialise UI
        setContentView(R.layout.activity_payment);

        // Get the application data model
        model = ((BarPosApplication) getApplication()).getModel();
    }

    @Override
    protected void onStart() {
        super.onStart();

        int tableNumber = getIntent().getIntExtra(BarPosApplication.TABLE_KEY, 0);
        table = model.getTables().get(tableNumber);

        // Set the total amount text
        updateTip(0);
    }

    private void updateTip(float percentage) {
        // Total bill amount
        String currencySymbol = model.getCurrency().getSymbol();
        String totalAmountString = currencySymbol + " " + table.getBill().getTotalAmount().toPlainString();

        // Obtain the tipping amount as a percentage of the total bill
        String tippingAmountString = "";
        if (percentage == 0) {
            tippingAmount = BigDecimal.ZERO;
        } else {
            tippingAmount = table.getBill().getTotalAmount().multiply(new BigDecimal(percentage / 100.0f))
                    .setScale(2, BigDecimal.ROUND_DOWN);
            tippingAmountString = totalAmountString + "\n+ " + currencySymbol + " " + tippingAmount.toPlainString();
            totalAmountString = currencySymbol + " "
                    + table.getBill().getTotalAmount().add(tippingAmount).toPlainString();
        }

        ((TextView) findViewById(R.id.totalAmountText)).setText(totalAmountString);
        ((TextView) findViewById(R.id.tippingAmountText)).setText(tippingAmountString);
    }

    /**
     * Add a tip to the bill
     *
     * @param view the clicked view
     */
    public void onTipButtonClick(View view) {
        Button button = (Button) view;

        switch (button.getId()) {
            case R.id.tipButton5Percent:
                updateTip(5);
                break;
            case R.id.tipButton10Percent:
                updateTip(10);
                break;
            case R.id.tipButton15Percent:
                updateTip(15);
                break;
            case R.id.tipButtonNoTip:
                updateTip(0);
                break;
        }
    }

    /**
     * Cancel the payment and close the screen
     *
     * @param view the clicked view
     */
    public void onCancelButtonClick(View view) {
        finish();
    }

    /**
     * Pay the bill by sending an Intent to the Payment App
     *
     * @param view the clicked view
     */
    public void onPayButtonClick(View view) {
        PaymentRequest payment = new PaymentRequest(table.getBill().getTotalAmount());
        payment.setTipAmount(tippingAmount);
        payment.setCurrency(model.getCurrency());
        startActivityForResult(payment.createIntent(), 0);
    }

    /**
     * Called by Android when the payment application returns control to this activity.
     *
     * @param requestCode the code associated with the request (0)
     * @param resultCode  the Intent result code
     * @param data        the result data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {

            // construct the transaction data from the intent
            TransactionResult result = TransactionResult.fromIntent(data);

            // show a message with the result
            if (result.getTransactionStatus() == TransactionStatus.APPROVED) {
                table.createNewBill();
                Toast toast = Toast.makeText(this, "Transaction Successful", Toast.LENGTH_LONG);
                toast.show();
                finish();
            } else {
                String message = "Transaction failed. Reason: " + result.getTransactionStatus() + " - " + result.getTransactionErrorCode();
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }
}