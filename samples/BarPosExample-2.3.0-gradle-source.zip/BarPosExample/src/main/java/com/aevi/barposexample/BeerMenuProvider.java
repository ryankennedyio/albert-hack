package com.aevi.barposexample;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.aevi.barposexample.model.Category;
import com.aevi.barposexample.model.Item;
import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.model.Table;
import com.aevi.payment.PaymentAppConfiguration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Currency;

public final class BeerMenuProvider {

    private static final String TAG = BeerMenuProvider.class.getSimpleName();

    private static final int NUMBER_OF_TABLES = 12;

    private BeerMenuProvider() {
    }

    public static Model getModel(Context context) throws JSONException {
        Model newModel = new Model(getDefaultCurrency(context));
        addTables(newModel);

        JSONObject jsonObject = new JSONObject(readJsonFile(context));
        JSONArray categories = jsonObject.getJSONArray("categories");
        for (int i = 0; i < categories.length(); i++) {
            Log.d(TAG, "Number of categories found :" + categories.length());
            JSONObject jsonCategory = categories.getJSONObject(i);
            Category category = new Category(jsonCategory.getString("name"));
            JSONArray beers = jsonCategory.getJSONArray("beers");
            addBeers(category, beers);
            newModel.addCategory(category);
        }
        return newModel;
    }

    private static void addBeers(Category category, JSONArray beers) throws JSONException {
        for (int j = 0; j < beers.length(); j++) {
            Log.d(TAG, "Number of beers found :" + beers.length());
            JSONObject jsonBeer = beers.getJSONObject(j);
            category.addItem(new Item(jsonBeer.getString("name"), new BigDecimal(jsonBeer.getString("price")), 0));
        }
    }

    private static void addTables(Model newModel) {
        for (int i = 0; i < NUMBER_OF_TABLES; i++) {
            newModel.addTable(new Table(i));
        }
    }

    private static Currency getDefaultCurrency(Context context) {
        PaymentAppConfiguration configuration = BarPosApplication.getPaymentAppConfiguration();
        return configuration.getDefaultCurrency();
    }

    private static String readJsonFile(Context context) {
        InputStream inputStream = context.getResources().openRawResource(R.raw.beers);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int i;
        try {
            i = inputStream.read();
            while (i != -1) {
                byteArrayOutputStream.write(i);
                i = inputStream.read();
            }
            inputStream.close();
            return byteArrayOutputStream.toString();
        } catch (IOException e) {
            throw new IllegalStateException("Error while reading the resource file");
        }
    }
}