/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.model;

/**
 * A table in our bar.
 */
public class Table {

    // Each table in our restaurant has a unique number that servers use to refer to them.
    private final int tableNumber;

    // The tab for the people currently at the table. If there are no people at the table, this will
    // an empty tab, but it will never be null
    private Bill bill = new Bill();

    /**
     * Constructs a new table for our restaurant.
     *
     * @param tableNumber unique table number user by servers to identify the table.
     */
    public Table(int tableNumber) {
        this.tableNumber = tableNumber;
    }

    /**
     * @return the unique identification number of the table.
     */
    public int getTableNumber() {
        return tableNumber;
    }

    /**
     * Gets the bill for the people currently at the table. If there are not people at the table, the bill will simply be
     * empty.
     *
     * @return the bill of the people currently at the table.
     */
    public Bill getBill() {
        return bill;
    }

    /**
     * Creates a new tab for the table.
     */
    public void createNewBill() {
        this.bill = new Bill();
    }
}
