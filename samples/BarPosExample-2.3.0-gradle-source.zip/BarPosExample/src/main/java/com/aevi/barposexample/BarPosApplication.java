/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample;

import android.app.Application;

import com.aevi.barposexample.model.Model;
import com.aevi.payment.PaymentAppConfiguration;

import org.json.JSONException;

/**
 * Bar point of sale (POS) system. This class holds the shared state (model) of the application.
 */
public class BarPosApplication extends Application {

    // Key used to exchange
    public static final String TABLE_KEY = "table";

    private static PaymentAppConfiguration paymentAppConfiguration = null;

    private Model model;

    public Model getModel() {
        if (model == null) {
            try {
                model = BeerMenuProvider.getModel(this);
            } catch (JSONException e) {
                throw new IllegalStateException("Error while initialising model", e);
            }
        }
        return model;
    }

    public static void setPaymentAppConfiguration(PaymentAppConfiguration paymentAppConfiguration) {
        BarPosApplication.paymentAppConfiguration = paymentAppConfiguration;
    }

    public static PaymentAppConfiguration getPaymentAppConfiguration() {
        return paymentAppConfiguration;
    }
}
