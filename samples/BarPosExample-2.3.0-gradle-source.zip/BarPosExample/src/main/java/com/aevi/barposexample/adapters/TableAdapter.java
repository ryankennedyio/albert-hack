/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.adapters;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.model.Table;
import com.aevi.barposexample.views.TableView;

/**
 * Adapter for the set of tables in the model. Uses {@link TableView} to render the tables.
 */
public class TableAdapter extends ArrayAdapter<Table> {

    private final Model model;
    private final OnClickListener clickListener;

    /**
     * Create a new {@link TableAdapter} instance.
     *
     * @param context       the Android context
     * @param model         the bar POS model
     * @param clickListener the table click event handler
     */
    public TableAdapter(Context context, Model model, OnClickListener clickListener) {
        super(context, 0, model.getTables());
        this.model = model;
        this.clickListener = clickListener;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TableView ret;
        Table table = getItem(position);

        if (convertView == null) {
            ret = new TableView(getContext(), model, table);
            ret.setOnClickListener(clickListener);
        } else {
            ret = (TableView) convertView;
            ret.setTable(table);
        }

        return ret;
    }
}
