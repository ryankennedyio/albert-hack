/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.adapters;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.aevi.barposexample.model.Category;
import com.aevi.barposexample.model.Item;
import com.aevi.barposexample.model.Model;
import com.aevi.barposexample.views.ItemView;

/**
 * Category helper class used for drawing and counting
 */
public class ItemAdapter extends BaseAdapter {

    private final Context context;
    private final Model model;
    private final Category category;
    private final OnClickListener clickListener;

    /**
     * Construct a new {@link CategoryAdapter} instance
     *
     * @param context       the Android context
     * @param model         the bar POS model
     * @param category      the item category
     * @param clickListener item click event handler
     */
    public ItemAdapter(Context context, Model model, Category category, OnClickListener clickListener) {
        this.context = context;
        this.model = model;
        this.category = category;
        this.clickListener = clickListener;
    }

    @Override
    public int getCount() {
        return category.getItems().size();
    }

    @Override
    public Object getItem(int position) {
        return category.getItems().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ItemView ret;
        Item item = category.getItems().get(position);

        if (convertView == null) {
            ret = new ItemView(context, model, item);
            ret.setOnClickListener(clickListener);
        } else {
            ret = (ItemView) convertView;
            ret.setItem(item);
        }

        return ret;
    }
}
