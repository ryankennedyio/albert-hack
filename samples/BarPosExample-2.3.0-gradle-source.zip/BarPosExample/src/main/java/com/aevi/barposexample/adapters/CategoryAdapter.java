/*
 * This sample code is a preliminary draft for illustrative purposes only and not subject to any license granted by Wincor Nixdorf.
 * The sample code is provided “as is” and Wincor Nixdorf assumes no responsibility for errors or omissions of any kind out of the
 * use of such code by any third party. 
 */
package com.aevi.barposexample.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.aevi.barposexample.R;
import com.aevi.barposexample.model.Category;

import java.util.List;

/**
 * Adapter class for the categories in the model
 */
public class CategoryAdapter extends ArrayAdapter<Category> {

    private final OnClickListener buttonClickListener;

    /**
     * Creates a new {@link CategoryAdapter} instance from a list of categories.
     *
     * @param context             Android context, for creating new CategoryButton instances
     * @param categories          list of categories
     * @param buttonClickListener click event listener
     */
    public CategoryAdapter(Context context, List<Category> categories, OnClickListener buttonClickListener) {
        super(context, 0, categories);
        this.buttonClickListener = buttonClickListener;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Button ret = null;
        Category category = getItem(position);

        if (convertView == null) {
            ret = new Button(getContext());
            ret.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.category_button));
            ret.setOnClickListener(buttonClickListener);
            ret.setHeight(100);
            ret.setTextSize(18);
            ret.setTextColor(Color.WHITE);
        } else {
            ret = (Button) convertView;
        }

        ret.setText(category.getName());

        return ret;
    }

}
